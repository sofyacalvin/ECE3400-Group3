%                               14    |16.5 19        24      28        33
x = [ 0 1 1 1 1 1 0 0 0 0 1 2 3 4 4 4 4 3 2 2 2 3 4 4 4 4 4 3 2 2 2 2 1 0 0 0 1 2 3 4 ];
y = [ 3 3 3 2 1 1 1 1 2 2 2 2 2 2 2 3 3 3 3 3 3 3 3 3 2 1 1 1 1 1 0 0 0 0 0 0 0 0 0 0 ];

o = [ 1 1 0 0 0 3 3 2 2 1 1 1 1 1 2 2 3 3 3 2 1 1 1 0 0 0 3 3 3 0 0 3 3 3 2 1 1 1 1 1 ];

N = [ 0 0 0 0 0 1 1 0 0 0 0 0 0 0 0 0 0 1 1 0 1 1 0 0 0 1 1 0 0 0 1 1 1 1 0 1 1 1 1 1 ];
E = [ 0 1 1 0 1 0 0 0 0 0 0 0 0 1 1 1 0 0 0 0 0 0 1 1 1 1 0 0 0 0 0 0 0 0 0 0 0 0 0 1 ];
S = [ 1 1 0 0 0 0 0 0 0 0 0 1 1 0 0 1 1 1 1 1 1 1 1 0 0 0 0 0 0 0 0 0 1 1 1 1 1 0 0 1 ];
W = [ 0 0 0 0 0 0 0 1 1 0 0 0 0 0 0 0 0 0 1 1 0 0 0 0 0 0 0 0 1 1 0 0 0 1 1 0 0 0 0 0 ];

% 1 = 7k; 2 = 12k; 4 = 17k;
T = [ 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ];

d = [ 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 ];

test = zeros(1,length(x));
test2 = zeros(1,length(x));
for i = 1:length(x)
    test(i) = bitor(bitor(bitor(bitor(bitor(S(i),bitshift(E(i),1)),bitshift(N(i),2)),bitshift(T(i),3)),bitshift(d(i),6)), bitshift(1,7));
    %display(dec2bin(test(i),8));
    test2(i) = bitor(bitor(bitor(y(i),bitshift(x(i),2)),bitshift(o(i),5)),bitshift(W(i),7));
    %display(dec2bin(test2(i),8));
    display(sprintf( 'B%s << 8 | B%s,', dec2bin(test(i),8), dec2bin(test2(i),8)));
end
