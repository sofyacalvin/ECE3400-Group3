xvec = [31, 131, 151, 251, 271, 371, 391, 491, 511, 0];
yvec = [11, 111, 131, 231, 251, 351, 371, 0];


fileID = fopen ('xmins.list', 'w');
for i = 1:9
    fprintf (fileID, '%x\n', xvec(i)); 
end
fprintf (fileID, '%x', xvec(10));
fclose (fileID);

fileID = fopen ('ymins.list', 'w');
for i = 1:7
    fprintf (fileID, '%x\n', yvec(i)); 
end
fprintf (fileID, '%x', yvec(8));
fclose (fileID);