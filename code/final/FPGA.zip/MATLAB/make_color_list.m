%read the image
I = imread('lines3.jpg');	
imshow(I);
		
%Extract RED, GREEN and BLUE components from the image
R = I(:,:,1);			
G = I(:,:,2);
B = I(:,:,3);

R = floor(R/(255/(7)));
G = floor(G/(255/(7)));
B = floor(B/(255/(3)));

COLOR = R.*2^(2+3) + G.*2^2 + B;

fileID = fopen ('lines3.list', 'w');
for i = 1:size(COLOR(:), 1)-1
%for i = size(COLOR(:), 1)-1:1
    fprintf (fileID, '%x\n', COLOR(i)); % COLOR (dec) -> print to file (hex)
end
fprintf (fileID, '%x', COLOR(size(COLOR(:), 1))); % COLOR (dec) -> print to file (hex)
fclose (fileID);