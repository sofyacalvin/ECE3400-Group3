%read the image
I = imread('test.jpg');	
imshow(I);
		
%Extract RED, GREEN and BLUE components from the image
R = I(:,:,1);			
G = I(:,:,2);
B = I(:,:,3);

% R = floor(R/(256/(2^3)));
% G = floor(G/(256/(2^3)));
% B = floor(B/(256/(2^2)));
% 
% COLOR = R.*2^(2+3) + G.*2^2 + B;

% fileID = fopen ('test.list', 'w');
% %for i = 1:size(COLOR(:), 1)-1
% for i = size(COLOR(:), 1)-1:1
%     fprintf (fileID, '%x\n', COLOR(i)); % COLOR (dec) -> print to file (hex)
% end
% fprintf (fileID, '%x', COLOR(size(COLOR(:), 1))); % COLOR (dec) -> print to file (hex)
% fclose (fileID);
% R2 = reshape(R,10000,1);
% G2 = reshape(G,10000,1);
% B2 = reshape(B,10000,1);
% R2 = R;
% G2 = G;
% B2 = B;
% x=2;
% y=50;
% R2((x+y*100)) = 255;
% G2((x+y*100)) = 255;
% B2((x+y*100)) = 255;
R(x+y*100) = 255;
COLOR2=zeros(100,100,3);
COLOR3=zeros(100,100,3);
COLOR2(:,:,1)=R;
COLOR2(:,:,2)=G;
COLOR2(:,:,3)=B;

% 
% color2reshape = reshape(COLOR2, 10000,1,3);
% 
% for xcol = 1:100
%     for yrow = 1:100
%         COLOR3(yrow,xcol
%reshape(COLOR,100,100);
imshow((COLOR2./255));
