"""
 Example program to show using an array to back a grid on-screen.

 Sample Python/Pygame Programs
 Simpson College Computer Science
 http://programarcadegames.com/
 http://simpson.edu/computer-science/

 Explanation video: http://youtu.be/mdTeqiWyFnc
"""

import pygame
# from models import *
import models
from constants import *
import time

# Create a 2 dimensional array. A two dimensional
# array is simply a list of lists.
grid = []
for row in range(ROWS): # number rows
    grid.append([])
    for column in range(COLS): # number columns
        grid[row].append(0)

hwall = []
for row in range(ROWS + 1): # number rows
    hwall.append([])
    for column in range(COLS): # number columns
        hwall[row].append(1)

vwall = []
for row in range(ROWS): # number rows
    vwall.append([])
    for column in range(COLS + 1): # number columns
        vwall[row].append(1)


maze = models.Maze()
maze.makeSquares()

HWALL  = [[1,1,1,1,1],
          [0,0,1,0,0],
          [0,1,0,0,0],
          [0,1,1,1,0],
          [1,1,1,1,1]]

VWALL  = [[1,0,0,0,0,1],
          [1,0,1,0,0,1],
          [1,1,0,1,0,1],
          [1,0,0,0,0,1]]

maze.setupWalls(HWALL,VWALL)


# Initialize pygame
pygame.init()

# Set the HEIGHT and WIDTH of the screen
screen = pygame.display.set_mode(WINDOW_SIZE)

# Set title of screen
pygame.display.set_caption("Maze Simulation")

# Loop until the user clicks the close button.
done = False

# Used to manage how fast the screen updates
clock = pygame.time.Clock()

squares = maze.squares
print(squares[0][0])
start = squares[0][0]
print(start)




# Maze.updateWalls(maze)

def dfs(graph, start):
    visited, frontier, path = [], [start], []
    goback = 0

    while frontier:
        if (goback != 1):
            current = frontier.pop()
            print "current is "  + str(current.x) + " " + str(current.y)
            grid[current.x][current.y] = 2 # set blue
            time.sleep(0.5)
            draw(grid)

            if current not in visited:
                visited.append(current)
                path.append(current)

            """ DEFINE NEXT """
            ### USING NEW CLASS VERSION
            length = len(frontier)
            if current.up == 0: #if no wall to top
                print "go up"
                next =  squares[current.x - 1][current.y] #up one
                hwall[current.x][current.y] = 0
                if next not in visited:
                    frontier.append(next)
            if current.left == 0: #if no wall to left
                print "go left"
                next =  squares[current.x][current.y - 1] #left one
                vwall[current.x][current.y] = 0
                if next not in visited:
                    frontier.append(next)
            if current.down == 0: #if no wall to below
                print "go down"
                next =  squares[current.x + 1][current.y] #down one
                hwall[current.x + 1][current.y] = 0
                if next not in visited:
                    frontier.append(next)
            if current.right == 0: #if no wall to right
                print "go right"
                next =  squares[current.x][current.y + 1] # right one
                vwall[current.x][current.y + 1] = 0
                if next not in visited:
                    frontier.append(next)
            if (len(frontier)>length):
                goback = 0
            else:
                goback = 1
            print "next is "  + str(next.x) + " " + str(next.y)
            grid[current.x][current.y] = 1 # set green
        else:
            print(len(path))
            for node in frontier:
                if (node in visited):
                    frontier.remove(node)
            tmp2 = path.pop()
            if (len(frontier) != 0):
                frontier.append(tmp2)
            goback = 0





    return visited

def draw(g):
        # Draw the grid
    # Set the screen background
    screen.fill(GREY)

    for row in range(ROWS):
        for col in range(COLS):
            color = WHITE
            if g[row][col] == 1:
                color = GREEN
            elif g[row][col] == 2:
                color = BLUE
            pygame.draw.rect(screen,
                             color,
                             [(MARGIN + WIDTH) * col + MARGIN,
                              (MARGIN + HEIGHT) * row + MARGIN,
                              WIDTH,
                              HEIGHT])
    for row in range(ROWS+1):
        for col in range(COLS):
            if hwall[row][col] == 1:
                color = BLACK
                pygame.draw.rect(screen,
                                 color,
                                 [(MARGIN + WIDTH) * col,
                                  (MARGIN + HEIGHT) * row,
                                  WIDTH + MARGIN,
                                  MARGIN])
    for row in range(ROWS):
        for col in range(COLS+1):
            if vwall[row][col] == 1:
                color = BLACK
                pygame.draw.rect(screen,
                                 color,
                                 [(MARGIN + WIDTH) * col,
                                  (MARGIN + HEIGHT) * row,
                                  MARGIN,
                                  HEIGHT + MARGIN])

    pygame.display.flip()

# -------- Main Program Loop -----------
while not done:
    for event in pygame.event.get():  # User did something
        if event.type == pygame.QUIT:  # If user clicked close
            done = True  # Flag that we are done so we exit this loop
        elif event.type == pygame.MOUSEBUTTONDOWN:
            # User clicks the mouse. Get the position
            pos = pygame.mouse.get_pos()
            # Change the x/y screen coordinates to grid coordinates
            column = pos[0] // (WIDTH + MARGIN)
            row = pos[1] // (HEIGHT + MARGIN)
            # Set that location to one
            # grid[row][column] = 1
            print("Grid coordinates: ", row, column)

    dfs(grid, start)


    # Limit to 60 frames per second
    clock.tick(60)

    # Go ahead and update the screen with what we've drawn.
    pygame.display.flip()
    #screen.fill(RED)
    time.sleep(5)
    done = True

# Be IDLE friendly. If you forget this line, the program will 'hang'
# on exit.
pygame.quit()
