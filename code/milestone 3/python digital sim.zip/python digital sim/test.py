import pygame
from constants import *
import models
# import constants
import time

pygame.init()

screen = pygame.display.set_mode(WINDOW_SIZE)
screen.fill(GREY)
pygame.draw.rect(screen, BLACK,
                 [(MARGIN + WIDTH) * 0,
                  (MARGIN + HEIGHT) * 0,
                  WIDTH + MARGIN,
                  MARGIN])
pygame.display.flip()
while(1):
    time.sleep(1)
