class Square():
    """ Instance is each grid square

    """

    def __init__(self, x, y, right, down, left, up, orientation):
        self.x = x
        self.y = y
        self.right = right
        self.down = down
        self.left = left
        self.up = up
        self.orientation = orientation

#    def checkWall(self):
