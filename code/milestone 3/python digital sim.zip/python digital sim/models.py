from constants import *

class Square():
	""" 
	Instance is each grid square

	"""

	def __init__(self, x, y, index, right, down, left, up):
		self.x = x
		self.y = y
		self.index = index
		self.right = right
		self.down = down
		self.left = left
		self.up = up
		#self.prev = prev
		#self.next = next
		# self.orientation = orientation

class Maze(object):
	"""
	iteration of maze
	"""

	def __init__(self):
		tmp = []
		for row in range(ROWS):
			tmp.append([])
			for col in range(COLS):
				tmp[row].append(0)

		self.squares = tmp

	def getSquares(self):
		return self.squares

	def makeSquares(self):
		x = 0
		y = 0
		index = 0
		right = 0
		down = 0
		left = 0
		up = 0
		for row in range(ROWS):
			for col in range(COLS):
				self.squares[row][col] = (Square(row, col, index, right, down, left, up))
				# y = y + 1
				index = index + 1
			# index = index + 1
			# y = 0
			# x = x + 1

	def setupWalls(self, hwall, vwall):
		for row in range(ROWS):
			for col in range(COLS):
				if hwall[row][col] == 1:
					self.squares[row][col].up = 1

				if hwall[row + 1][col] == 1:
					self.squares[row][col].down = 1

				if vwall[row][col] == 1:
					self.squares[row][col].left = 1

				if vwall[row][col + 1] == 1:
					self.squares[row][col].right = 1


		