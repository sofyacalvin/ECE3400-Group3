"""
 Example program to show using an array to back a grid on-screen.
 
 Sample Python/Pygame Programs
 Simpson College Computer Science
 http://programarcadegames.com/
 http://simpson.edu/computer-science/
 
 Explanation video: http://youtu.be/mdTeqiWyFnc
"""

import pygame
from models import *
from constants import *
import time
 
# Create a 2 dimensional array. A two dimensional
# array is simply a list of lists.
grid = []
for row in range(ROWS): # number rows
    grid.append([])
    for column in range(COLS): # number columns
        grid[row].append(0) 

maze = Maze()
print maze
 
# Initialize pygame
pygame.init()
 
# Set the HEIGHT and WIDTH of the screen
screen = pygame.display.set_mode(WINDOW_SIZE)
 
# Set title of screen
pygame.display.set_caption("Maze Simulation")
 
# Loop until the user clicks the close button.
done = False
 
# Used to manage how fast the screen updates
clock = pygame.time.Clock()

squares = Maze.getSquares(maze)
start = squares[0]

# lmao sorry this is how i did the border

squares[0].up = 1
squares[1].up = 1
squares[2].up = 1
squares[3].up = 1
squares[4].up = 1
squares[4].right = 1
squares[9].right = 1
squares[14].right = 1
squares[19].right = 1
squares[0].left = 1
squares[5].left = 1
squares[10].left = 1
squares[15].left = 1
squares[15].down = 1
squares[16].down = 1
squares[17].down = 1
squares[18].down = 1
squares[19].down = 1


def dfs(graph, start):
    visited, frontier = [], [start]
    
    while frontier:
        current = frontier.pop()

        print "current is "  + str(current.x) + " " + str(current.y)
        print "current index "  + str(current.index)

        if current not in visited:
            visited.append(current)
            grid[current.x][current.y] = 1 # set green
            time.sleep(1)
            draw(grid)

            """ DEFINE NEXT """

            ### USING NEW CLASS VERSION

            if current.up == 0: #if no wall to top
                print "go up"
                next =  squares[current.index - 5] #up one
                frontier.append(next)
            if current.left == 0: #if no wall to left
                print "go left"
                next =  squares[current.index - 1] #left one
                frontier.append(next)
            if current.down == 0: #if no wall to below
                print "go down"
                next =  squares[current.index + 5] #down one
                frontier.append(next)
            if current.right == 0: #if no wall to right
                print "go right"
                next =  squares[current.index + 1] # right one
                frontier.append(next)
            
            """
            ### EXCEPTION HANDLING VERSION
            try: 
            	next = [current[0], current[1] + 1] # right one
            	if next in visited:
            		raise IndexError
            	grid[next[0]][next[1]]
            except:
            	try:
            		next = [current[0] + 1, current[1]] #down one
            		if next in visited:
            			raise IndexError
            		grid[next[0]][next[1]]
            	except:
            		try:
            			next = [current[0], current[1] - 1] #left one
            			if next in visited:
            				raise IndexError
            			grid[next[0]][next[1]]
            		except:
            			next = [current[0] - 1, current[1]] #up one
            			if next in visited:
            				raise IndexError
            			grid[next[0]][next[1]]
			"""

            print "next is "  + str(next.x) + " " + str(next.y)
            print "next index "  + str(next.index)
            # frontier.append(next)
    return visited

def draw(grid):
        # Draw the grid
    for row in range(4):
        for column in range(5):
            color = WHITE
            if grid[row][column] == 1:
                color = GREEN
            pygame.draw.rect(screen,
                             color,
                             [(MARGIN + WIDTH) * column + MARGIN,
                              (MARGIN + HEIGHT) * row + MARGIN,
                              WIDTH,
                              HEIGHT])

    pygame.display.flip()

# -------- Main Program Loop -----------
while not done:
    for event in pygame.event.get():  # User did something
        if event.type == pygame.QUIT:  # If user clicked close
            done = True  # Flag that we are done so we exit this loop
        elif event.type == pygame.MOUSEBUTTONDOWN:
            # User clicks the mouse. Get the position
            pos = pygame.mouse.get_pos()
            # Change the x/y screen coordinates to grid coordinates
            column = pos[0] // (WIDTH + MARGIN)
            row = pos[1] // (HEIGHT + MARGIN)
            # Set that location to one
            # grid[row][column] = 1
            print("Grid coordinates: ", row, column)
	
	dfs(grid, start)
 
    # Set the screen background
    screen.fill(GREY)
 
    # Limit to 60 frames per second
    clock.tick(60)
 
    # Go ahead and update the screen with what we've drawn.
    pygame.display.flip()
 
# Be IDLE friendly. If you forget this line, the program will 'hang'
# on exit.
pygame.quit()