"""
 Example program to show using an array to back a grid on-screen.
 
 Sample Python/Pygame Programs
 Simpson College Computer Science
 http://programarcadegames.com/
 http://simpson.edu/computer-science/
 
 Explanation video: http://youtu.be/mdTeqiWyFnc
"""

import pygame
from models import *
from constants import *

 
# Create a 2 dimensional array. A two dimensional
# array is simply a list of lists.
grid = []
for row in range(ROWS): # number rows
    grid.append([])
    for column in range(COLS): # number columns
        grid[row].append(0) 

maze = Maze()
print maze
 
# Initialize pygame
pygame.init()
 
# Set the HEIGHT and WIDTH of the screen
screen = pygame.display.set_mode(WINDOW_SIZE)
 
# Set title of screen
pygame.display.set_caption("Maze Simulation")
 
# Loop until the user clicks the close button.
done = False
 
# Used to manage how fast the screen updates
clock = pygame.time.Clock()

squares = Maze.getSquares(maze)
start = squares[0]

squares[0].right = 1
#squares[1].right = 1
#squares[2].right = 1


def dfs(graph, start):
    visited, frontier = [], [start]
    
    while frontier:
        current = frontier.pop()

        print "current is "  + str(current.x) + " " + str(current.y)

        if current not in visited:
            visited.append(current)
            grid[current.x][current.y] = 1 # set green
            
            """ DEFINE NEXT """

            ### USING NEW CLASS VERSION

            if current.up == 0: #if no wall to top
                next =  squares[current.index - 5] #up one
                frontier.append(next)
            elif current.left == 0: #if no wall to right
                next =  squares[current.index - 1] #left one
                frontier.append(next)
            elif current.down == 0: #if no wall to right
                next =  squares[current.index + 5] #down one
                frontier.append(next)
            elif current.right == 0: #if no wall to right
                next =  squares[current.index + 1] # right one
                frontier.append(next)
            
            """
            ### EXCEPTION HANDLING VERSION
            try: 
            	next = [current[0], current[1] + 1] # right one
            	if next in visited:
            		raise IndexError
            	grid[next[0]][next[1]]
            except:
            	try:
            		next = [current[0] + 1, current[1]] #down one
            		if next in visited:
            			raise IndexError
            		grid[next[0]][next[1]]
            	except:
            		try:
            			next = [current[0], current[1] - 1] #left one
            			if next in visited:
            				raise IndexError
            			grid[next[0]][next[1]]
            		except:
            			next = [current[0] - 1, current[1]] #up one
            			if next in visited:
            				raise IndexError
            			grid[next[0]][next[1]]
			"""

            # print "next is " + str(next)
            # frontier.append(next)
    return visited

# -------- Main Program Loop -----------
while not done:
    for event in pygame.event.get():  # User did something
        if event.type == pygame.QUIT:  # If user clicked close
            done = True  # Flag that we are done so we exit this loop
        elif event.type == pygame.MOUSEBUTTONDOWN:
            # User clicks the mouse. Get the position
            pos = pygame.mouse.get_pos()
            # Change the x/y screen coordinates to grid coordinates
            column = pos[0] // (WIDTH + MARGIN)
            row = pos[1] // (HEIGHT + MARGIN)
            # Set that location to one
            # grid[row][column] = 1
            print("Grid coordinates: ", row, column)
	
	dfs(grid, start)
	# grid[1][1] = 1
 
    # Set the screen background
    screen.fill(GREY)
 
    # Draw the grid
    for row in range(4):
        for column in range(5):
            color = WHITE
            if grid[row][column] == 1:
                color = GREEN
            pygame.draw.rect(screen,
                             color,
                             [(MARGIN + WIDTH) * column + MARGIN,
                              (MARGIN + HEIGHT) * row + MARGIN,
                              WIDTH,
                              HEIGHT])
 
    # Limit to 60 frames per second
    clock.tick(60)
 
    # Go ahead and update the screen with what we've drawn.
    pygame.display.flip()
 
# Be IDLE friendly. If you forget this line, the program will 'hang'
# on exit.
pygame.quit()