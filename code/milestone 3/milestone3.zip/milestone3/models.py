from constants import *

class Square():
	""" 
	Instance is each grid square

	"""

	def __init__(self, x, y, index, right, down, left, up):
		self.x = x
		self.y = y
		self.index = index
		self.right = right
		self.down = down
		self.left = left
		self.up = up
		# self.orientation = orientation

class Maze(object):
	"""
	iteration of maze
	"""

	def __init__(self):
		self._squares = []
		self.makeSquares();

	def getSquares(self):
		return self._squares

	def makeSquares(self):
		x = 0
		y = 0
		index = 0
		right = 0
		down = 0
		left = 0
		up = 0
		for row in range(ROWS):
			for col in range(COLS):
				self._squares.append(Square(x, y, index, right, down, left, up))
				x = x + 1
				index = index + 1
			y = y + 1

	def updateWalls(self):
		for i in range(index):
			if self._squares(index - 1).right == 1:	
				left = 1
			if self._squares(index - 5).down == 1:
				up = 1
			if self._squares(index + 1).left == 1:
				right = 1	
			if self._squares(index + 5).up == 1:
				down = 1